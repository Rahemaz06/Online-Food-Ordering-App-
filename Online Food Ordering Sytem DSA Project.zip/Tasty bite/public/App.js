// TastyBite v2 - app.js
const API = 'http://localhost:3000/api';
const menuData = [
  {id:1,category:'italian',name:'Margherita Pizza',desc:'Classic tomato sauce, fresh mozzarella & basil leaves',price:850,image:'https://images.unsplash.com/photo-1574071318508-1cdbab80d002?w=500&q=90',badge:'Bestseller'},
  {id:2,category:'italian',name:'Pepperoni Pizza',desc:'Loaded with spicy pepperoni, mozzarella & tomato sauce',price:1100,image:'https://images.unsplash.com/photo-1628840042765-356cda07504e?w=500&q=90'},
  {id:3,category:'italian',name:'Fettuccine Alfredo',desc:'Creamy white sauce pasta with garlic & parmesan',price:750,image:'https://images.unsplash.com/photo-1628079251261-624e723b7326?q=80&w=735&auto=format&fit=crop&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D',badge:"Chef's Pick"},
  {id:4,category:'italian',name:'Penne Arrabbiata',desc:'Spicy tomato & chilli sauce with penne pasta',price:700,image:'https://images.unsplash.com/photo-1621996346565-e3dbc646d9a9?w=500&q=90'},
  {id:5,category:'italian',name:'Lasagna al Forno',desc:'Classic layered pasta filled with chicken, vegetables and white sauce',price:950,image:'https://images.unsplash.com/photo-1574894709920-11b28e7367e3?q=80&w=735&auto=format&fit=crop&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D',badge:'Popular'},
  {id:6,category:'desi',name:'Chicken Biryani',desc:'Aromatic basmati rice cooked with tender chicken & spices',price:650,image:'https://images.unsplash.com/photo-1563379091339-03b21ab4a4f8?w=500&q=90',badge:'Bestseller'},
  {id:7,category:'desi',name:'Chicken Karahi',desc:'Wok-cooked chicken with tomatoes, green chillies & spices',price:900,image:'https://images.unsplash.com/photo-1708782340793-ec5f2159a689?q=80&w=880&auto=format&fit=crop&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D',badge:'Spicy 🌶️'},
  {id:8,category:'desi',name:'Chicken Handi',desc:'Rich & creamy chicken cooked in a traditional clay handi',price:950,image:'https://images.unsplash.com/photo-1574653853027-5382a3d23a15?w=500&q=90'},
  {id:9,category:'desi',name:'Mutton Qorma',desc:'Slow-cooked tender mutton in aromatic golden spices',price:1200,image:'https://images.unsplash.com/photo-1545247181-516773cae754?w=500&q=90'},
  {id:10,category:'desi',name:'Palak Paneer',desc:'Fresh cottage cheese in smooth spiced spinach gravy',price:750,image:'https://images.unsplash.com/photo-1589647363585-f4a7d3877b10?q=80&w=1172&auto=format&fit=crop&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D'},
  {id:11,category:'chinese',name:'Chicken Chowmein',desc:'Stir-fried noodles with vegetables & tender chicken',price:600,image:'https://images.unsplash.com/photo-1607328874071-45a9cd600644?q=80&w=1171&auto=format&fit=crop&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D',badge:'Popular'},
  {id:12,category:'chinese',name:'Steamed Dumplings',desc:'8 pieces of juicy chicken dumplings with dipping sauce',price:550,image:'https://images.unsplash.com/photo-1496116218417-1a781b1c416c?w=500&q=90',badge:'Bestseller'},
  {id:13,category:'chinese',name:'Chicken Fried Rice',desc:'Wok-tossed jasmine rice with egg, vegetables & soy sauce',price:550,image:'https://images.unsplash.com/photo-1603133872878-684f208fb84b?w=500&q=90'},
  {id:14,category:'chinese',name:'Crispy Spring Rolls',desc:'4 golden crispy rolls filled with vegetables & chicken',price:450,image:'https://images.unsplash.com/photo-1695712641569-05eee7b37b6d?q=80&w=1170&auto=format&fit=crop&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D'},
  {id:15,category:'chinese',name:'Kung Pao Chicken',desc:'Classic spicy stir-fry with peanuts, peppers & dried chilli',price:750,image:'https://png.pngtree.com/thumb_back/fh260/background/20240401/pngtree-bowl-of-kung-pao-chicken-image_15644337.jpg',badge:'Spicy 🌶️'},
  {id:16,category:'beverages',name:'Chai',desc:'Traditional Pakistani strong milk tea, brewed to perfection',price:80,image:'https://therecipespk.com/wp-content/uploads/2022/03/How-to-Make-Dodh-Pati.jpg',badge:'Must Try'},
  {id:17,category:'beverages',name:'Cold Coffee',desc:'Blended iced coffee with cream & chocolate drizzle',price:250,image:'https://images.unsplash.com/photo-1461023058943-07fcbe16d735?w=500&q=90'},
  {id:18,category:'beverages',name:'Mineral Water',desc:'500ml chilled fresh mineral water',price:60,image:'https://images.unsplash.com/photo-1548839140-29a749e1cf4d?w=500&q=90'},
  {id:19,category:'beverages',name:'Coca-Cola',desc:'330ml ice-cold fizzy Coca-Cola can',price:100,image:'https://www.shutterstock.com/image-photo/yerevan-armenia-11272025-can-cocacola-600nw-2709409325.jpg'},
  {id:20,category:'beverages',name:'Mango Lassi',desc:'Thick creamy mango yogurt drink, chilled & sweet',price:200,image:'https://images.unsplash.com/photo-1623065422902-30a2d299bbe4?q=80&w=687&auto=format&fit=crop&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D',badge:'Seasonal'},
  {id:21,category:'beverages',name:'Lemon Mint Cooler',desc:'Refreshing lemon soda with fresh mint & crushed ice',price:180,image:'https://images.unsplash.com/photo-1621263764928-df1444c5e859?w=500&q=90'},
  {id:22,category:'bread',name:'Tandoori Roti',desc:'Freshly baked whole wheat roti straight from the tandoor',price:30,image:'https://images.unsplash.com/photo-1633030318854-b076ff72770f?q=80&w=1170&auto=format&fit=crop&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D',badge:'Fresh'},
  {id:24,category:'bread',name:'Garlic Naan',desc:'Soft pillowy naan brushed with garlic butter & herbs',price:120,image:'https://png.pngtree.com/background/20250521/original/pngtree-naan-garlic-cheese-picture-image_16523473.jpg',badge:'Popular'},
  {id:26,category:'bread',name:'Lachha Paratha',desc:'Multi-layered crispy paratha with a golden flaky texture',price:100,image:'https://images.unsplash.com/photo-1668357530437-72a12c660f94?q=80&w=687&auto=format&fit=crop&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D'},
  {id:27,category:'bread',name:'Garlic Bread',desc:'Toasted baguette with creamy garlic butter & herbs, golden & crispy',price:180,image:'https://plus.unsplash.com/premium_photo-1711752902734-a36167479983?q=80&w=688&auto=format&fit=crop&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D',badge:'New'},
  {id:28,category:'bread',name:'Cheese Bread',desc:'Soft bread loaded with melted mozzarella & cheddar cheese',price:220,image:'https://images.unsplash.com/photo-1681285353147-5b40678b7807?q=80&w=1974&auto=format&fit=crop&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D',badge:'New'},
];

const categories=[
  {id:'all',label:'All Items',icon:'🍽️'},
  {id:'italian',label:'Italian',icon:'🇮🇹'},
  {id:'desi',label:'Desi',icon:'🌶️'},
  {id:'chinese',label:'Chinese',icon:'🥢'},
  {id:'beverages',label:'Beverages',icon:'☕'},
  {id:'bread',label:'Bread & Roti',icon:'🥖'},
];
const sectionMeta={
  italian:{title:'Italian',sub:'Pizza • Pasta • Lasagna',icon:'🍕'},
  desi:{title:'Desi',sub:'Biryani • Karahi • Handi',icon:'🍛'},
  chinese:{title:'Chinese',sub:'Chowmein • Dumplings • Fried Rice',icon:'🥢'},
  beverages:{title:'Beverages',sub:'Tea • Coffee • Cold Drinks',icon:'☕'},
  bread:{title:'Breads & Roti',sub:'Roti • Paratha • Naan • Garlic Bread',icon:'🥖'},
};
const trackingStages=[
  {icon:'✅',title:'Order Confirmed',desc:'Your order has been received and confirmed.'},
  {icon:'👨‍🍳',title:'Preparing Your Food',desc:'Our chef is cooking your delicious meal.'},
  {icon:'📦',title:'Packed & Ready',desc:'Your order has been packed and is ready for pickup.'},
  {icon:'🛵',title:'Out for Delivery',desc:'Our delivery rider is on the way to your address.'},
  {icon:'🏠',title:'Delivered!',desc:'Your order has been successfully delivered. Enjoy your meal!'},
];
const GST_RATE=0.15, DELIVERY_CHARGE=50;
const ADMIN_CREDS={name:'Admin',email:'admin@tastybite.com',password:'admin123'};

let cart=[],currentUser=null,orderHistory=[],selectedPayment='',currentPage='home';
let customItems=[],adminItems=[...menuData];
let trackingInterval=null;

// Password rule labels — fixed, static strings
const PW_RULE_LABELS = {
  'pw-len':     'Minimum 8 characters',
  'pw-upper':   'At least one uppercase letter (A-Z)',
  'pw-lower':   'At least one lowercase letter (a-z)',
  'pw-special': 'At least one special character (!@#$%)',
};

document.addEventListener('DOMContentLoaded',()=>{
  loadFromStorage(); updateCartBadge(); showPage('home'); renderMenuPage(); renderCategoryNav();
});

function showPage(p){
  document.querySelectorAll('.page').forEach(x=>x.classList.remove('active'));
  const t=document.getElementById('page-'+p); if(t) t.classList.add('active');
  currentPage=p;
  document.querySelectorAll('.nav-link[data-page]').forEach(l=>l.classList.toggle('active',l.dataset.page===p));
  window.scrollTo({top:0,behavior:'smooth'});
}

function loadFromStorage(){
  if(!localStorage.getItem('tb_users')) localStorage.setItem('tb_users',JSON.stringify([]));
  const cu=localStorage.getItem('tb_current_user'); if(cu) currentUser=JSON.parse(cu);
  const co=localStorage.getItem('tb_orders'); if(co) orderHistory=JSON.parse(co);
  const cc=localStorage.getItem('tb_cart'); if(cc) cart=JSON.parse(cc);
  const ci=localStorage.getItem('tb_custom_items'); if(ci){customItems=JSON.parse(ci);rebuildMenu();}
  updateAuthUI();
}
function getUsers(){return JSON.parse(localStorage.getItem('tb_users')||'[]');}
function saveUsers(u){localStorage.setItem('tb_users',JSON.stringify(u));}
function saveCart(){localStorage.setItem('tb_cart',JSON.stringify(cart));}
function saveOrders(){localStorage.setItem('tb_orders',JSON.stringify(orderHistory));}
function saveCustomItems(){localStorage.setItem('tb_custom_items',JSON.stringify(customItems));}
function setCurrentUser(u){currentUser=u;localStorage.setItem('tb_current_user',JSON.stringify(u));updateAuthUI();}
function rebuildMenu(){adminItems=[...menuData,...customItems];}

function updateAuthUI(){
  const ll=document.getElementById('nav-login-link'),rl=document.getElementById('nav-reg-link'),
        lo=document.getElementById('nav-logout-link'),hl=document.getElementById('nav-history-link'),
        tl=document.getElementById('nav-tracking-link'),ug=document.getElementById('nav-user');
  if(currentUser){
    if(ll) ll.style.display='none'; if(rl) rl.style.display='none';
    if(lo) lo.style.display='inline-flex'; if(hl) hl.style.display='inline-flex';
    if(tl) tl.style.display='inline-flex';
    if(ug){ug.style.display='block';ug.textContent=`Hi, ${currentUser.firstName}! 👋`;}
  } else {
    if(ll) ll.style.display='inline-flex'; if(rl) rl.style.display='inline-flex';
    if(lo) lo.style.display='none'; if(hl) hl.style.display='none';
    if(tl) tl.style.display='none';
    if(ug) ug.style.display='none';
  }
}

// ============================================================
// AUTH
// ============================================================
async function doRegister(){
  const fn=v('reg-firstname'),ln=v('reg-lastname'),ph=v('reg-phone'),
        em=v('reg-email'),pw=v('reg-password'),ad=v('reg-address');
  if(!fn||!ln||!ph||!em||!pw||!ad){showAlert('reg-alert','error','⚠️ Please fill in all fields!');return;}
  if(!validEmail(em)){showAlert('reg-alert','error','❌ Invalid email! Use: abc@gmail.com');return;}
  if(!validPhone(ph)){showAlert('reg-alert','error','❌ Enter a valid phone number.');return;}
  const pwCheck=validatePassword(pw);
  if(!pwCheck.valid){showAlert('reg-alert','error',`❌ ${pwCheck.msg}`);return;}

  try{
    const res = await fetch(`${API}/auth/register`,{
      method:'POST', headers:{'Content-Type':'application/json'},
      body: JSON.stringify({first_name:fn,last_name:ln,phone:ph,email:em,password:pw,address:ad})
    });
    const data = await res.json();
    if(data.success){
      showAlert('reg-alert','success',`✅ Successfully registered! Welcome, ${fn}!`);
      setTimeout(()=>{clearForm(['reg-firstname','reg-lastname','reg-phone','reg-email','reg-password','reg-address']);showPage('login');},1800);
    } else {
      showAlert('reg-alert','error','❌ '+data.msg);
    }
  } catch(e){
    showAlert('reg-alert','error','❌ Server error! Try again.');
  }
}

async function doLogin(){
  const em=v('login-email'),pw=v('login-password');
  if(!em||!pw){showAlert('login-alert','error','⚠️ Please enter both fields!');return;}
  if(!validEmail(em)){showAlert('login-alert','error','❌ Invalid email format!');return;}

  try{
    const res = await fetch(`${API}/auth/login`,{
      method:'POST', headers:{'Content-Type':'application/json'},
      body: JSON.stringify({email:em, password:pw})
    });
    const data = await res.json();
    if(data.success){
      setCurrentUser(data.user);
      showAlert('login-alert','success',`✅ You are successfully logged in! Welcome, ${data.user.firstName}!`);
      setTimeout(()=>{clearForm(['login-email','login-password']);showPage('menu');},1500);
    } else {
      showAlert('login-alert','error','❌ '+data.msg);
    }
  } catch(e){
    showAlert('login-alert','error','❌ Server error! Try again.');
  }
}

function doLogout(){
  currentUser=null; localStorage.removeItem('tb_current_user');
  cart=[]; saveCart(); updateCartBadge(); updateCartSidebar(); updateAuthUI(); showPage('home');
  showToast('👋 Logged out successfully!','info');
}

function doAdminLogin(){
  const name=v('admin-login-name'),email=v('admin-login-email'),pass=v('admin-login-password');
  if(!name||!email||!pass){showAlert('admin-login-alert','error','⚠️ Please fill all fields!');return;}
  if(name===ADMIN_CREDS.name&&email===ADMIN_CREDS.email&&pass===ADMIN_CREDS.password){
    showAlert('admin-login-alert','success','✅ Admin login successful!');
    setTimeout(()=>{showPage('admin');renderAdminPanel();},1000);
  } else {
    showAlert('admin-login-alert','error','❌ Invalid admin credentials!<br><small>Hint: Name=Admin, Email=admin@tastybite.com, Pass=admin123</small>');
  }
}
function adminLogout(){showPage('home');showToast('👋 Admin logged out!','info');}

// ============================================================
// MENU
// ============================================================
function renderMenuPage(){
  const container=document.getElementById('menu-sections-container'); if(!container) return;
  const order=['italian','desi','chinese','beverages','bread'];
  let html='';
  order.forEach(catId=>{
    const items=adminItems.filter(i=>i.category===catId);
    const meta=sectionMeta[catId];
    html+=`<section class="menu-section" id="section-${catId}">
      <div class="menu-section-header">
        <div class="menu-section-icon">${meta.icon}</div>
        <div><div class="menu-section-title">${meta.title} <span>${meta.sub}</span></div></div>
      </div>
      <div class="food-grid">${items.map(item=>foodCardHTML(item)).join('')}</div>
    </section>`;
  });
  container.innerHTML=html;
}

function foodCardHTML(item){
  return `<div class="food-card">
    ${item.badge?`<div class="food-badge">${item.badge}</div>`:''}
    <img class="food-card-img" src="${item.image}" alt="${item.name}" onerror="this.src='https://images.unsplash.com/photo-1504674900247-0877df9cc836?w=400&q=80'"/>
    <div class="food-card-body">
      <div class="food-card-name">${item.name}</div>
      <div class="food-card-desc">${item.desc}</div>
      <div class="food-card-footer">
        <div class="food-price">Rs. ${item.price.toLocaleString()} <span>/serving</span></div>
        <button class="add-to-cart-btn" onclick="addToCart(${item.id})" title="Add to cart">+</button>
      </div>
    </div>
  </div>`;
}

function renderCategoryNav(){
  const nav=document.getElementById('category-nav'); if(!nav) return;
  nav.innerHTML=categories.map(cat=>`<button class="cat-tab ${cat.id==='all'?'active':''}" onclick="filterCategory('${cat.id}',this)">${cat.icon} ${cat.label}</button>`).join('');
}

function filterCategory(catId,btn){
  document.querySelectorAll('.cat-tab').forEach(t=>t.classList.remove('active')); btn.classList.add('active');
  if(catId==='all'){document.querySelectorAll('.menu-section').forEach(s=>s.style.display='block');}
  else{
    document.querySelectorAll('.menu-section').forEach(s=>{s.style.display=s.id===`section-${catId}`?'block':'none';});
    const t=document.getElementById(`section-${catId}`); if(t) t.scrollIntoView({behavior:'smooth',block:'start'});
  }
}

// ============================================================
// CART
// ============================================================
function addToCart(id) {
  const item = menuData.find(i => i.id === id);
  if (!item) return;

  // Local array update
  const existing = cart.find(i => i.id === id);
  if (existing) {
    existing.qty++;
  } else {
    cart.push({ ...item, qty: 1 });
  }
  updateCartUI();
  showToast(`${item.name} cart mein add ho gaya! 🛒`);

  // ✅ DATABASE mein bhi save karo
  const user = JSON.parse(localStorage.getItem('tastyUser') || 'null');
  if (user && user.id) {
    fetch(`${API}/cart/add`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        user_id: user.id,
        menu_item_id: id
      })
    })
    .then(r => r.json())
    .then(data => {
      if (!data.success) console.warn('Cart DB save fail:', data.msg);
    })
    .catch(err => console.warn('Cart API error:', err));
  }
}

function openCart(){document.getElementById('cart-overlay').classList.add('open');document.getElementById('cart-sidebar').classList.add('open');updateCartSidebar();}
function closeCart(){document.getElementById('cart-overlay').classList.remove('open');document.getElementById('cart-sidebar').classList.remove('open');}

// ============================================================
// PAYMENT
// ============================================================
function selectPayment(method,el){
  selectedPayment=method;
  document.querySelectorAll('.pay-method').forEach(m=>m.classList.remove('selected'));
  el.classList.add('selected');
  if(method!=='cash') openPaymentModal(method);
}

function openPaymentModal(method){
  const mo=document.getElementById('pay-modal-overlay');
  document.getElementById('pay-modal-icon').innerHTML = method==='easypaisa'?'📱':method==='jazzcash'?'<span style="font-family:sans-serif;font-weight:900;font-size:1.1em;color:#dc143c;background:#fff;border-radius:50%;width:1.4em;height:1.4em;display:inline-flex;align-items:center;justify-content:center;border:2px solid #dc143c;">J</span>':'💳';
  document.getElementById('pay-modal-title').textContent = method==='easypaisa'?'EasyPaisa Payment':method==='jazzcash'?'JazzCash Payment':'Card Payment';
  const b=document.getElementById('pay-modal-body');
  if(method==='easypaisa'||method==='jazzcash'){
    b.innerHTML=`
      <div class="form-group"><label class="form-label">Registered Mobile No.</label>
      <div class="input-wrap"><span class="input-icon">📱</span><input class="form-input" id="pm-phone" placeholder="03XX-XXXXXXX"/></div></div>
      <div class="form-group"><label class="form-label">${method==='jazzcash'?'MPIN':'4-Digit PIN'}</label>
      <div class="input-wrap"><span class="input-icon">🔒</span><input class="form-input" type="password" id="pm-pin" placeholder="Enter your PIN" maxlength="6"/><button type="button" class="eye-btn" onclick="togglePw('pm-pin',this)" title="Show/Hide">👁️</button></div></div>
      <div class="alert" id="pm-alert"></div>
      <div style="display:flex;gap:.8rem;margin-top:1rem;">
        <button class="btn btn-primary" style="flex:1;" onclick="confirmPayModal('${method}')">✅ Confirm Payment</button>
        <button class="btn btn-ghost" style="flex:1;" onclick="closePayModal()">Cancel</button>
      </div>`;
  } else {
    b.innerHTML=`
      <div class="form-group"><label class="form-label">Card Number</label>
      <div class="input-wrap"><span class="input-icon">💳</span><input class="form-input" id="pm-card" placeholder="XXXX XXXX XXXX XXXX" maxlength="19"/></div></div>
      <div class="row-2">
        <div class="form-group"><label class="form-label">Expiry</label>
        <div class="input-wrap"><span class="input-icon">📅</span><input class="form-input" id="pm-expiry" placeholder="MM/YY" maxlength="5"/></div></div>
        <div class="form-group"><label class="form-label">CVV</label>
        <div class="input-wrap"><span class="input-icon">🔐</span><input class="form-input" type="password" id="pm-cvv" placeholder="XXX" maxlength="3"/><button type="button" class="eye-btn" onclick="togglePw('pm-cvv',this)" title="Show/Hide">👁️</button></div></div>
      </div>
      <div class="form-group"><label class="form-label">Cardholder Name</label>
      <div class="input-wrap"><span class="input-icon">👤</span><input class="form-input" id="pm-name" placeholder="Name on card"/></div></div>
      <div class="alert" id="pm-alert"></div>
      <div style="display:flex;gap:.8rem;margin-top:1rem;">
        <button class="btn btn-primary" style="flex:1;" onclick="confirmPayModal('card')">✅ Confirm Payment</button>
        <button class="btn btn-ghost" style="flex:1;" onclick="closePayModal()">Cancel</button>
      </div>`;
    setTimeout(()=>{
      const ci=document.getElementById('pm-card');
      if(ci) ci.addEventListener('input',e=>{let val=e.target.value.replace(/\D/g,'').substring(0,16);e.target.value=val.replace(/(\d{4})(?=\d)/g,'$1 ');});
    },100);
  }
  mo.classList.add('open');
}

function confirmPayModal(method){
  if(method==='easypaisa'||method==='jazzcash'){
    const p=document.getElementById('pm-phone')?.value.trim(),pin=document.getElementById('pm-pin')?.value.trim();
    if(!p||!pin){showAlert('pm-alert','error','⚠️ Please fill all fields!');return;}
    if(!validPhone(p)){showAlert('pm-alert','error','❌ Enter a valid mobile number!');return;}
    if(pin.length<4){showAlert('pm-alert','error','❌ PIN must be 4-6 digits!');return;}
  } else {
    const card=document.getElementById('pm-card')?.value.replace(/\s/g,'');
    const ex=document.getElementById('pm-expiry')?.value.trim();
    const cvv=document.getElementById('pm-cvv')?.value.trim();
    const nm=document.getElementById('pm-name')?.value.trim();
    if(!card||!ex||!cvv||!nm){showAlert('pm-alert','error','⚠️ Please fill all card details!');return;}
    if(card.length<16){showAlert('pm-alert','error','❌ Enter a valid 16-digit card number!');return;}
  }
  showAlert('pm-alert','success','✅ Payment confirmed successfully!');
  setTimeout(()=>closePayModal(),1500);
}
function closePayModal(){document.getElementById('pay-modal-overlay').classList.remove('open');}

// ============================================================
// CHECKOUT
// ============================================================
function goToCheckout(){
  if(!currentUser){showToast('🔐 Please login first!','error');return;}
  if(cart.length===0){showToast('🛒 Your cart is empty!','error');return;}
  closeCart(); renderCheckoutPage(); showPage('checkout');
}

function renderCheckoutPage(){
  const el=document.getElementById('checkout-order-items'); if(!el) return;
  el.innerHTML=cart.map(i=>`<div class="order-item-row">
    <span class="name"><img src="${i.image}" style="width:28px;height:28px;border-radius:6px;object-fit:cover;margin-right:4px;" onerror="this.remove()"/>${i.name} ×${i.qty}</span>
    <span class="price">Rs. ${(i.price*i.qty).toLocaleString()}</span>
  </div>`).join('');
  const sub=cartSubtotal(),gst=cartGST(),total=cartTotal();
  const cs=document.getElementById('co-subtotal'),cg=document.getElementById('co-gst'),cd=document.getElementById('co-delivery'),ct=document.getElementById('co-total');
  if(cs) cs.textContent=`Rs. ${sub.toLocaleString()}`;
  if(cg) cg.textContent=`Rs. ${gst.toLocaleString()} (15%)`;
  if(cd) cd.textContent=`Rs. ${DELIVERY_CHARGE}`;
  if(ct) ct.textContent=`Rs. ${total.toLocaleString()}`;
  if(currentUser){
    const ae=document.getElementById('checkout-address'),ne=document.getElementById('checkout-name'),pe=document.getElementById('checkout-phone');
    if(ae) ae.value=currentUser.address||'';
    if(ne) ne.value=`${currentUser.firstName} ${currentUser.lastName}`;
    if(pe) pe.value=currentUser.phone||'';
  }
}

async function placeOrder() {
  const user = JSON.parse(localStorage.getItem('tastyUser') || 'null');
 
  if (!user || !user.id) {
    showToast('Pehle login karo! 🔐');
    openModal('authModal');
    return;
  }
 
  if (cart.length === 0) {
    showToast('Cart khali hai!');
    return;
  }
 
  const subtotal = cart.reduce((sum, i) => sum + i.price * i.qty, 0);
  const gst      = Math.round(subtotal * 0.05);
  const delivery = 50;
  const total    = subtotal + gst + delivery;
 
  const paymentMethod  = document.querySelector('input[name="payment"]:checked')?.value || 'cod';
  const deliveryAddr   = user.address || 'Not provided';
 
  // ✅ items array bilkul theek format mein — backend dono qty/quantity accept karta hai
  const orderItems = cart.map(i => ({
    id:       i.id,
    name:     i.name,
    price:    i.price,
    qty:      i.qty,
    quantity: i.qty   // dono bhejo for safety
  }));
 
  try {
    const res = await fetch(`${API}/orders/place`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        user_id:          user.id,
        items:            orderItems,
        total_price:      total,
        gst:              gst,
        payment_method:   paymentMethod,
        delivery_address: deliveryAddr
      })
    });
 
    const data = await res.json();
 
    if (data.success) {
      // Cart clear karo — local aur DB dono
      cart = [];
      updateCartUI();
      fetch(`${API}/cart/clear/${user.id}`, { method: 'DELETE' }).catch(() => {});
 
      closeModal('cartModal');
      showOrderSuccess(data.orderId, total);
    } else {
      showToast('Order fail: ' + (data.msg || 'Server error'));
    }
  } catch (err) {
    console.error('Order error:', err);
    showToast('Network error — server se connection nahi hua');
  }
}
 

function closeModal(){
  document.getElementById('modal-overlay').classList.remove('open');
  renderTrackingPage(); showPage('tracking');
}

// ============================================================
// TRACKING
// ============================================================
function startTracking(order){
  clearInterval(trackingInterval);
  let stage=order.trackingStage||0;
  const stageMessages=['✅ Order Confirmed!','👨‍🍳 Chef is preparing your food...','📦 Your order is packed!','🛵 Rider is on the way!','🏠 Delivered! Enjoy your meal!'];
  trackingInterval=setInterval(()=>{
    stage++;
    const idx=orderHistory.findIndex(o=>o.id===order.id);
    if(idx===-1){clearInterval(trackingInterval);return;}
    orderHistory[idx].trackingStage=stage;
    if(stage>=trackingStages.length-1){
      orderHistory[idx].status='Delivered';
      orderHistory[idx].trackingStage=trackingStages.length-1;
      clearInterval(trackingInterval);
      showToast('🏠 Your order has been successfully delivered!','success');
      if('Notification' in window && Notification.permission==='granted') new Notification('TastyBite 🍽️',{body:'Your order has been successfully delivered!'});
    } else {
      showToast(stageMessages[stage],'info');
    }
    saveOrders();
    if(currentPage==='tracking') renderTrackingPage();
  },8000);
}

function renderTrackingPage(){
  const cont=document.getElementById('tracking-content'); if(!cont) return;
  const order=currentUser?orderHistory.find(o=>o.userEmail===currentUser.email):null;
  if(!order){cont.innerHTML=`<div class="no-orders-msg"><span class="icon">📋</span><p>No active order found.</p></div>`;return;}
  const stage=order.trackingStage||0;
  const isDel=order.status==='Delivered';
  const steps=trackingStages.map((s,i)=>`<div class="track-step ${i<stage?'done':i===stage?'active':''}">
    <div class="track-step-title">${s.icon} ${s.title}</div>
    <div class="track-step-desc">${i<=stage?s.desc:'Pending...'}</div>
    ${i===stage&&!isDel?`<div class="track-step-time">⏳ In Progress</div>`:''}
  </div>`).join('');
  cont.innerHTML=`<div class="tracking-card">
    <div class="tracking-header">
      <div class="order-id-label">Order ID</div>
      <div class="order-id-val">${order.id}</div>
      <div style="font-size:.85rem;color:var(--gray-400);margin-top:.3rem">📅 ${order.date} • 🕐 ${order.time}</div>
    </div>
    ${isDel?`<div class="delivered-banner"><span class="del-icon">🎉</span><h3>Order Successfully Delivered!</h3><p>Your food has arrived. Enjoy your meal!</p></div>`
    :`<div style="background:var(--pink-50);border-radius:10px;padding:.8rem 1rem;margin-bottom:1.5rem;font-size:.85rem;color:var(--pink-600);font-weight:600;text-align:center;">🔄 Live Tracking — Auto-updates every few seconds</div>`}
    <div class="tracking-steps">${steps}</div>
    <div style="margin-top:2rem;display:flex;gap:1rem;flex-wrap:wrap;">
      <button class="btn btn-outline btn-sm" onclick="goToHistory()">📋 All Orders</button>
      <button class="btn btn-primary btn-sm" onclick="showPage('menu')">🍽️ Order More</button>
    </div>
  </div>`;
}

function goToTracking(){
  if(!currentUser){showToast('🔐 Please login!','error');return;}
  renderTrackingPage(); showPage('tracking');
}

// ============================================================
// ORDER HISTORY
// ============================================================
function goToHistory(){
  if(!currentUser){showToast('🔐 Please login!','error');showPage('login');return;}
  renderOrderHistory('all'); showPage('history');
}

function renderOrderHistory(filter){
  const c=document.getElementById('order-history-list'); if(!c) return;
  let orders=orderHistory.filter(o=>o.userEmail===currentUser.email);
  const now=Date.now();
  if(filter==='recent') orders=orders.filter(o=>(now-o.timestamp)<259200000);
  if(filter==='old')    orders=orders.filter(o=>(now-o.timestamp)>=259200000);
  if(orders.length===0){c.innerHTML=`<div class="no-orders-msg"><span class="icon">📋</span><p>No orders found.</p></div>`;return;}
  c.innerHTML=orders.map(o=>`<div class="order-history-card">
    <div class="order-history-top">
      <div>
        <div class="order-history-id">🧾 ${o.id}</div>
        <div class="order-history-date">📅 ${o.date} • 🕐 ${o.time||'N/A'}</div>
      </div>
      <div class="order-status ${o.status==='Delivered'?'status-delivered':'status-confirmed'}">${o.status==='Delivered'?'✅ Delivered':'🔄 In Progress'}</div>
    </div>
    <div class="order-history-items">${o.items.map(i=>`${i.name} ×${i.qty}`).join(' • ')}</div>
    <div style="font-size:.8rem;color:var(--gray-400);margin-bottom:.4rem">
      Subtotal: Rs. ${(o.subtotal||0).toLocaleString()} + GST: Rs. ${(o.gst||0).toLocaleString()} + Delivery: Rs. ${o.deliveryCharge||50}
    </div>
    <div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:.5rem;">
      <div class="order-history-total">Total: Rs. ${o.total.toLocaleString()}</div>
      ${o.status!=='Delivered'?`<button class="btn btn-outline btn-sm" onclick="goToTracking()">📍 Track Order</button>`:''}
    </div>
  </div>`).join('');
}

function filterHistory(filter,btn){
  document.querySelectorAll('.history-tab').forEach(t=>t.classList.remove('active')); btn.classList.add('active');
  renderOrderHistory(filter);
}

// ============================================================
// ADMIN PANEL
// ============================================================
function renderAdminPanel(){
  const latestOrders=JSON.parse(localStorage.getItem('tb_orders')||'[]');
  const latestUsers=JSON.parse(localStorage.getItem('tb_users')||'[]');
  orderHistory=latestOrders;

  const ai=document.getElementById('admin-total-items'),ao=document.getElementById('admin-total-orders'),
        ac=document.getElementById('admin-total-customers'),ad=document.getElementById('admin-delivered');
  if(ai) ai.textContent=adminItems.length;
  if(ao) ao.textContent=latestOrders.length;
  if(ac) ac.textContent=latestUsers.length;
  if(ad) ad.textContent=latestOrders.filter(o=>o.status==='Delivered').length;

  document.querySelectorAll('.admin-tab-panel').forEach(p=>p.style.display='none');
  const menuTab=document.getElementById('admin-tab-menu');
  if(menuTab) menuTab.style.display='block';
  document.querySelectorAll('.admin-tab-btn').forEach(b=>b.classList.remove('active'));
  const firstTab=document.querySelector('.admin-tab-btn');
  if(firstTab) firstTab.classList.add('active');

  const tbody=document.getElementById('admin-menu-tbody'); if(!tbody) return;
  tbody.innerHTML=adminItems.map(item=>`<tr>
    <td><img class="admin-item-img" src="${item.image}" alt="${item.name}" onerror="this.src='https://images.unsplash.com/photo-1504674900247-0877df9cc836?w=100&q=80'"/></td>
    <td><strong>${item.name}</strong></td>
    <td><span class="admin-badge badge-${item.category}">${item.category}</span></td>
    <td style="max-width:180px;font-size:.82rem;color:var(--gray-600)">${item.desc}</td>
    <td><strong style="color:var(--pink-500)">Rs. ${item.price}</strong></td>
    <td>
      <button class="btn btn-sm btn-outline" style="margin-right:.4rem" onclick="openAdminEdit(${item.id})">✏️ Edit</button>
      <button class="btn btn-sm btn-danger" onclick="adminDeleteItem(${item.id})">🗑️</button>
    </td>
  </tr>`).join('');
}

// ============================================================
// ADMIN — CUSTOMER ORDER HISTORY
// ============================================================
function renderAdminCustomerOrders(){
  const allOrders=JSON.parse(localStorage.getItem('tb_orders')||'[]');
  const allUsers=JSON.parse(localStorage.getItem('tb_users')||'[]');
  const container=document.getElementById('admin-customer-orders-list');
  if(!container) return;

  if(allUsers.length===0){
    container.innerHTML=`<div style="text-align:center;padding:3rem;color:#a0aec0;"><span style="font-size:3rem;display:block;margin-bottom:1rem;">👥</span><p>No registered customers yet.</p></div>`;
    return;
  }

  let html='';
  allUsers.forEach(user=>{
    const userOrders=allOrders.filter(o=>o.userEmail===user.email);
    const totalSpent=userOrders.reduce((s,o)=>s+o.total,0);
    html+=`
    <div style="background:white;border-radius:14px;margin-bottom:1.5rem;overflow:hidden;box-shadow:0 2px 12px rgba(0,0,0,0.07);border:1.5px solid #e2e8f0;">
      <div style="background:linear-gradient(135deg,#2d3748,#4a5568);padding:1rem 1.5rem;display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:.5rem;">
        <div style="display:flex;align-items:center;gap:.8rem;">
          <div style="width:42px;height:42px;background:linear-gradient(135deg,var(--pink-400),var(--pink-600));border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:1.1rem;font-weight:700;color:white;flex-shrink:0;">
            ${user.firstName.charAt(0).toUpperCase()}
          </div>
          <div>
            <div style="font-weight:700;color:white;font-size:.95rem;">${user.firstName} ${user.lastName}</div>
            <div style="font-size:.8rem;color:rgba(255,255,255,.65);">📧 ${user.email} &nbsp;|&nbsp; 📱 ${user.phone}</div>
          </div>
        </div>
        <div style="display:flex;gap:1rem;flex-wrap:wrap;">
          <div style="text-align:center;">
            <div style="font-size:1.2rem;font-weight:800;color:var(--pink-300);">${userOrders.length}</div>
            <div style="font-size:.72rem;color:rgba(255,255,255,.6);">Total Orders</div>
          </div>
          <div style="text-align:center;">
            <div style="font-size:1.2rem;font-weight:800;color:#68d391;">Rs. ${totalSpent.toLocaleString()}</div>
            <div style="font-size:.72rem;color:rgba(255,255,255,.6);">Total Spent</div>
          </div>
          <div style="text-align:center;">
            <div style="font-size:1.2rem;font-weight:800;color:#fbd38d;">${userOrders.filter(o=>o.status==='Delivered').length}</div>
            <div style="font-size:.72rem;color:rgba(255,255,255,.6);">Delivered</div>
          </div>
        </div>
      </div>
      <div style="padding:1rem 1.5rem;">
        ${userOrders.length===0
          ? `<div style="text-align:center;padding:1.5rem;color:#a0aec0;font-size:.88rem;">🛒 No orders placed yet.</div>`
          : userOrders.map(o=>`
            <div style="border:1.5px solid ${o.status==='Delivered'?'#9ae6b4':'#fef08a'};border-radius:10px;padding:1rem;margin-bottom:.8rem;background:${o.status==='Delivered'?'#f0fff4':'#fffbeb'};">
              <div style="display:flex;justify-content:space-between;align-items:flex-start;flex-wrap:wrap;gap:.5rem;margin-bottom:.7rem;">
                <div>
                  <div style="font-family:'Cormorant Garamond',serif;font-size:1.1rem;font-weight:700;color:#1a202c;">🧾 ${o.id}</div>
                  <div style="font-size:.78rem;color:#718096;margin-top:.15rem;">📅 ${o.date} &nbsp;•&nbsp; 🕐 ${o.time||'N/A'}</div>
                </div>
                <div style="display:flex;align-items:center;gap:.5rem;">
                  <span style="padding:.25rem .8rem;border-radius:50px;font-size:.72rem;font-weight:700;${o.status==='Delivered'?'background:#c6f6d5;color:#276749;border:1px solid #9ae6b4;':'background:#fef3c7;color:#92400e;border:1px solid #fcd34d;'}">
                    ${o.status==='Delivered'?'✅ Delivered':'🔄 In Progress'}
                  </span>
                  <span style="padding:.25rem .8rem;border-radius:50px;font-size:.72rem;font-weight:700;background:#e2e8f0;color:#4a5568;">
                    💳 ${o.paymentMethod==='cash'?'Cash on Delivery':o.paymentMethod==='easypaisa'?'EasyPaisa':o.paymentMethod==='jazzcash'?'JazzCash':'Card'}
                  </span>
                </div>
              </div>
              <div style="margin-bottom:.7rem;">
                <div style="font-size:.75rem;font-weight:700;color:#4a5568;text-transform:uppercase;letter-spacing:.05em;margin-bottom:.4rem;">Items Ordered:</div>
                <div style="display:flex;flex-wrap:wrap;gap:.4rem;">
                  ${o.items.map(i=>`<span style="background:white;border:1px solid #e2e8f0;border-radius:50px;padding:.2rem .7rem;font-size:.78rem;color:#2d3748;font-weight:600;">
                    ${i.name} <span style="color:var(--pink-500);">×${i.qty}</span>
                  </span>`).join('')}
                </div>
              </div>
              <div style="background:white;border-radius:8px;padding:.6rem .9rem;display:flex;gap:1.2rem;flex-wrap:wrap;font-size:.8rem;">
                <span style="color:#718096;">Subtotal: <strong style="color:#2d3748;">Rs. ${(o.subtotal||0).toLocaleString()}</strong></span>
                <span style="color:#718096;">GST(15%): <strong style="color:#2d3748;">Rs. ${(o.gst||0).toLocaleString()}</strong></span>
                <span style="color:#718096;">Delivery: <strong style="color:#2d3748;">Rs. ${o.deliveryCharge||50}</strong></span>
                <span style="color:#718096;font-weight:800;">Total: <strong style="color:var(--pink-600);font-size:.92rem;">Rs. ${o.total.toLocaleString()}</strong></span>
              </div>
              <div style="margin-top:.5rem;font-size:.78rem;color:#718096;">
                📍 ${o.address||'—'} &nbsp;|&nbsp; 📱 ${o.phone||'—'}
              </div>
            </div>
          `).join('')
        }
      </div>
    </div>`;
  });
  container.innerHTML=html;
}

function switchAdminTab(tab, btn){
  document.querySelectorAll('.admin-tab-btn').forEach(b=>b.classList.remove('active'));
  btn.classList.add('active');
  document.querySelectorAll('.admin-tab-panel').forEach(p=>p.style.display='none');
  document.getElementById('admin-tab-'+tab).style.display='block';
  if(tab==='customers') renderAdminCustomerOrders();
}

function openAdminEdit(itemId){
  const item=adminItems.find(i=>i.id===itemId); if(!item) return;
  document.getElementById('edit-item-id').value=item.id;
  document.getElementById('edit-item-name').value=item.name;
  document.getElementById('edit-item-price').value=item.price;
  document.getElementById('edit-item-desc').value=item.desc;
  document.getElementById('edit-item-img').value=item.image;
  window._adminEditItemImg=item.image;
  const prev=document.getElementById('edit-item-img-preview');
  if(prev){prev.src=item.image;prev.style.display='block';}
  const wrap=document.getElementById('edit-item-img-preview-wrap');
  if(wrap) wrap.style.display='flex';
  document.getElementById('admin-edit-modal').classList.add('open');
}

function adminEditImgFileChange(input){
  const file=input.files[0]; if(!file) return;
  const reader=new FileReader();
  reader.onload=function(e){
    window._adminEditItemImg=e.target.result;
    _showPreview('edit',e.target.result);
    const urlInput=document.getElementById('edit-item-img');
    if(urlInput) urlInput.value='';
  };
  reader.readAsDataURL(file);
}

function adminEditImgUrlChange(input){
  const url=input.value.trim();
  window._adminEditItemImg=url||null;
  if(url) _showPreview('edit',url);
  else{const prev=document.getElementById('edit-item-img-preview');if(prev){prev.src='';prev.style.display='none';}}
  const fi=document.getElementById('edit-item-file');
  if(fi) fi.value='';
}
function closeAdminEdit(){document.getElementById('admin-edit-modal').classList.remove('open');}

// ✅ FIX 1: saveAdminEdit — backend ko bhi update bhejo
async function saveAdminEdit(){
  const id=parseInt(document.getElementById('edit-item-id').value);
  const name=document.getElementById('edit-item-name').value.trim();
  const price=parseInt(document.getElementById('edit-item-price').value);
  const desc=document.getElementById('edit-item-desc').value.trim();
  const img=window._adminEditItemImg||document.getElementById('edit-item-img').value.trim();
  if(!name||!price||!desc){showToast('⚠️ Fill all fields!','error');return;}

  // Local arrays update
  const bi=menuData.findIndex(i=>i.id===id);
  if(bi!==-1){menuData[bi].name=name;menuData[bi].price=price;menuData[bi].desc=desc;if(img) menuData[bi].image=img;}
  const ci=customItems.findIndex(i=>i.id===id);
  if(ci!==-1){customItems[ci].name=name;customItems[ci].price=price;customItems[ci].desc=desc;if(img) customItems[ci].image=img;}

  // ✅ Database update — backend API call
  try{
    await fetch(`${API}/menu/update/${id}`,{
      method:'PUT',
      headers:{'Content-Type':'application/json'},
      body: JSON.stringify({name, price, description:desc, image_url:img})
    });
  } catch(e){
    console.warn('Backend update failed (local still updated):', e);
  }

  rebuildMenu(); saveCustomItems(); renderMenuPage(); renderAdminPanel(); closeAdminEdit();
  showToast('✅ Item updated!','success');
}

// ✅ FIX 2: adminDeleteItem — backend ko bhi delete request bhejo
async function adminDeleteItem(itemId){
  if(!confirm('Delete this item?')) return;

  // Local arrays se delete
  const bi=menuData.findIndex(i=>i.id===itemId); if(bi!==-1) menuData.splice(bi,1);
  const ci=customItems.findIndex(i=>i.id===itemId); if(ci!==-1) customItems.splice(ci,1);

  // ✅ Database se bhi delete — backend API call
  try{
    await fetch(`${API}/menu/${itemId}`,{method:'DELETE'});
  } catch(e){
    console.warn('Backend delete failed (local still deleted):', e);
  }

  rebuildMenu(); saveCustomItems(); renderMenuPage(); renderAdminPanel();
  showToast('🗑️ Item deleted!','info');
}

async function adminAddItem(){
  const name=document.getElementById('new-item-name').value.trim();
  const cat=document.getElementById('new-item-category').value;
  const price=parseInt(document.getElementById('new-item-price').value);
  const desc=document.getElementById('new-item-desc').value.trim();
  const img=window._adminNewItemImg||document.getElementById('new-item-img').value.trim();

  if(!name||!cat||!price||!desc){
    showAlert('add-item-alert','error','⚠️ Please fill all required fields!');
    return;
  }

  const defaults={
    italian:'https://images.unsplash.com/photo-1574071318508-1cdbab80d002?w=500&q=90',
    desi:'https://images.unsplash.com/photo-1563379091339-03b21ab4a4f8?w=500&q=90',
    chinese:'https://images.unsplash.com/photo-1569718212165-3a8278d5f624?w=500&q=90',
    beverages:'https://images.unsplash.com/photo-1571934811356-5cc061b6821f?w=500&q=90',
    bread:'https://images.unsplash.com/photo-1565557623262-b51c2513a641?w=500&q=90'
  };

  try{
    const res = await fetch(`${API}/menu/add`,{
      method:'POST',
      headers:{'Content-Type':'application/json'},
      body: JSON.stringify({
        category: cat, name, description: desc, price,
        image_url: img||defaults[cat]||defaults.desi, badge: ''
      })
    });
    const data = await res.json();
    if(data.success){
      customItems.push({
        id: data.id, category: cat, name, desc, price,
        image: img||defaults[cat]||defaults.desi
      });
      rebuildMenu(); saveCustomItems(); renderMenuPage(); renderAdminPanel();
      clearForm(['new-item-name','new-item-price','new-item-desc','new-item-img']);
      window._adminNewItemImg=null;
      const prev=document.getElementById('new-item-img-preview');
      if(prev){prev.src='';prev.style.display='none';}
      const wrap=document.getElementById('new-item-img-preview-wrap');
      if(wrap) wrap.style.display='none';
      const fi=document.getElementById('new-item-file');
      if(fi) fi.value='';
      showAlert('add-item-alert','success',`✅ "${name}" added to menu!`);
    } else {
      showAlert('add-item-alert','error','❌ Failed to add item!');
    }
  } catch(e){
    showAlert('add-item-alert','error','❌ Server error! Try again.');
    console.log(e);
  }
}

function adminImgFileChange(input){
  const file=input.files[0]; if(!file) return;
  const reader=new FileReader();
  reader.onload=function(e){
    window._adminNewItemImg=e.target.result;
    _showPreview('new',e.target.result);
    const urlInput=document.getElementById('new-item-img');
    if(urlInput) urlInput.value='';
  };
  reader.readAsDataURL(file);
}

function adminImgUrlChange(input){
  const url=input.value.trim();
  window._adminNewItemImg=url||null;
  if(url) _showPreview('new',url);
  else{const prev=document.getElementById('new-item-img-preview');if(prev){prev.src='';prev.style.display='none';}}
  const fi=document.getElementById('new-item-file');
  if(fi) fi.value='';
}

function switchImgTab(scope, tab, btn){
  const filePanel=document.getElementById(`${scope}-img-tab-file`);
  const urlPanel=document.getElementById(`${scope}-img-tab-url`);
  const tabs=btn.closest('.img-upload-tabs').querySelectorAll('.img-tab');
  tabs.forEach(t=>t.classList.remove('active'));
  btn.classList.add('active');
  if(tab==='file'){filePanel.style.display='block';urlPanel.style.display='none';}
  else{filePanel.style.display='none';urlPanel.style.display='block';}
}

function clearAdminImg(scope){
  if(scope==='new'){window._adminNewItemImg=null;const fi=document.getElementById('new-item-file');if(fi)fi.value='';const ui=document.getElementById('new-item-img');if(ui)ui.value='';}
  else{window._adminEditItemImg=null;const fi=document.getElementById('edit-item-file');if(fi)fi.value='';const ui=document.getElementById('edit-item-img');if(ui)ui.value='';}
  const wrapId=scope==='new'?'new-item-img-preview-wrap':'edit-item-img-preview-wrap';
  const wrap=document.getElementById(wrapId);
  if(wrap) wrap.style.display='none';
  const prev=document.getElementById(scope==='new'?'new-item-img-preview':'edit-item-img-preview');
  if(prev){prev.src='';prev.style.display='none';}
}

function _showPreview(scope, src){
  const wrapId=scope==='new'?'new-item-img-preview-wrap':'edit-item-img-preview-wrap';
  const wrap=document.getElementById(wrapId);
  const img=document.getElementById(scope==='new'?'new-item-img-preview':'edit-item-img-preview');
  if(wrap) wrap.style.display='flex';
  if(img){img.src=src;img.style.display='block';}
}

// ============================================================
// ✅ FIX 3: togglePw — Eye button properly toggle karo
// ============================================================
function togglePw(inputId, btn){
  const inp=document.getElementById(inputId);
  if(!inp) return;
  if(inp.type==='password'){
    inp.type='text';
    btn.textContent='🙈';
    btn.title='Hide Password';
  } else {
    inp.type='password';
    btn.textContent='👁️';
    btn.title='Show Password';
  }
}

// ============================================================
// ✅ FIX 4: checkPwStrength — static labels use karo, sirf prefix change karo
// ============================================================
function checkPwStrength(pw){
  const rules = {
    'pw-len':     pw.length >= 8,
    'pw-upper':   /[A-Z]/.test(pw),
    'pw-lower':   /[a-z]/.test(pw),
    'pw-special': /[^A-Za-z0-9]/.test(pw),
  };
  Object.entries(rules).forEach(([id, passed])=>{
    const el=document.getElementById(id);
    if(!el) return;
    el.textContent = (passed ? '✓ ' : '✗ ') + PW_RULE_LABELS[id];
    el.classList.toggle('pw-pass', passed);
    el.classList.toggle('pw-fail', !passed);
  });
}

// ============================================================
// UTILS
// ============================================================
let toastTimer;
function showToast(msg,type='info'){
  const t=document.getElementById('toast'); if(!t) return;
  t.textContent=msg; t.className=`toast ${type} show`;
  clearTimeout(toastTimer); toastTimer=setTimeout(()=>t.classList.remove('show'),3200);
}
function showAlert(id,type,msg){
  const el=document.getElementById(id); if(!el) return;
  el.className=`alert ${type} show`; el.innerHTML=msg;
}
function v(id){const el=document.getElementById(id);return el?el.value.trim():'';}
function validEmail(e){return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(e);}
function validPhone(p){return /^[0-9\-\+\s]{10,15}$/.test(p);}
function validatePassword(pw){
  if(pw.length<8) return {valid:false,msg:'Password must be at least 8 characters!'};
  if(!/[A-Z]/.test(pw)) return {valid:false,msg:'Password must include at least one uppercase letter (A-Z)!'};
  if(!/[a-z]/.test(pw)) return {valid:false,msg:'Password must include at least one lowercase letter (a-z)!'};
  if(!/[^A-Za-z0-9]/.test(pw)) return {valid:false,msg:'Password must include at least one special character (!@#$%^&*)!'};
  return {valid:true};
}
function clearForm(ids){ids.forEach(id=>{const el=document.getElementById(id);if(el) el.value='';});}
document.addEventListener('keydown',e=>{
  if(e.key==='Enter'){if(currentPage==='login') doLogin();if(currentPage==='register') doRegister();}
});