const express = require('express');
const router = express.Router();
const db = require('../db');

// GET cart for a user
router.get('/:userId', (req, res) => {
  db.query(
    `SELECT c.id, c.quantity, m.id as item_id, m.name, m.price, m.image_url
     FROM cart c JOIN menu_items m ON c.menu_item_id = m.id
     WHERE c.user_id = ?`,
    [req.params.userId],
    (err, rows) => {
      if (err) return res.json({ success: false, msg: err.message });
      res.json({ success: true, cart: rows });
    }
  );
});

// POST add to cart (user_id + menu_item_id)
router.post('/add', (req, res) => {
  const { user_id, menu_item_id } = req.body;

  if (!user_id || !menu_item_id)
    return res.json({ success: false, msg: 'user_id aur menu_item_id dono zaroori hain' });

  db.query(
    'SELECT * FROM cart WHERE user_id=? AND menu_item_id=?',
    [user_id, menu_item_id],
    (err, rows) => {
      if (err) return res.json({ success: false, msg: err.message });

      if (rows && rows.length > 0) {
        // Already in cart → quantity +1
        db.query(
          'UPDATE cart SET quantity = quantity + 1 WHERE id=?',
          [rows[0].id],
          (err2) => {
            if (err2) return res.json({ success: false, msg: err2.message });
            res.json({ success: true, action: 'updated' });
          }
        );
      } else {
        // New item → insert
        db.query(
          'INSERT INTO cart (user_id, menu_item_id, quantity) VALUES (?, ?, 1)',
          [user_id, menu_item_id],
          (err2) => {
            if (err2) return res.json({ success: false, msg: err2.message });
            res.json({ success: true, action: 'added' });
          }
        );
      }
    }
  );
});

// DELETE clear entire cart for a user
router.delete('/clear/:userId', (req, res) => {
  db.query(
    'DELETE FROM cart WHERE user_id=?',
    [req.params.userId],
    (err) => {
      if (err) return res.json({ success: false, msg: err.message });
      res.json({ success: true });
    }
  );
});

// DELETE remove single item from cart
router.delete('/remove/:cartId', (req, res) => {
  db.query(
    'DELETE FROM cart WHERE id=?',
    [req.params.cartId],
    (err) => {
      if (err) return res.json({ success: false, msg: err.message });
      res.json({ success: true });
    }
  );
});

module.exports = router;