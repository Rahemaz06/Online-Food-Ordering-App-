const express = require('express');
const router = express.Router();
const db = require('../db');
const bcrypt = require('bcryptjs');

router.post('/register', (req, res) => {
  const { first_name, last_name, phone, email, password, address } = req.body;
  if (!first_name || !email || !password)
    return res.json({ success: false, msg: 'Sab fields bharo!' });

  const hash = bcrypt.hashSync(password, 10);
  db.query(
    'INSERT INTO users (first_name,last_name,phone,email,password,address) VALUES (?,?,?,?,?,?)',
    [first_name, last_name, phone, email, hash, address],
    (err, result) => {
      if (err) {
        if (err.code === 'ER_DUP_ENTRY')
          return res.json({ success: false, msg: 'Email pehle se registered hai!' });
        return res.json({ success: false, msg: 'Server error' });
      }
      res.json({ success: true, userId: result.insertId });
    }
  );
});

router.post('/login', (req, res) => {
  const { email, password } = req.body;
  db.query('SELECT * FROM users WHERE email=?', [email], (err, rows) => {
    if (err || rows.length === 0)
      return res.json({ success: false, msg: 'Email ya password galat hai!' });
    if (!bcrypt.compareSync(password, rows[0].password))
      return res.json({ success: false, msg: 'Password galat hai!' });
    const u = rows[0];
    res.json({ success: true, user: {
      id: u.id, firstName: u.first_name, lastName: u.last_name,
      email: u.email, phone: u.phone, address: u.address
    }});
  });
});

module.exports = router;