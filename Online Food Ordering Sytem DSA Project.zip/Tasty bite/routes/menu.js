const express = require('express');
const router = express.Router();
const db = require('../db');

router.get('/', (req, res) => {
  db.query('SELECT * FROM menu_items', (err, rows) => {
    if (err) return res.json({ success: false });
    res.json({ success: true, items: rows });
  });
});

router.post('/add', (req, res) => {
  const { category, name, description, price, image_url, badge } = req.body;
  db.query(
    'INSERT INTO menu_items (category,name,description,price,image_url,badge,is_custom) VALUES (?,?,?,?,?,?,1)',
    [category, name, description, price, image_url, badge],
    (err, result) => {
      if (err) return res.json({ success: false });
      res.json({ success: true, id: result.insertId });
    }
  );
});
// PUT — item update karo
router.put('/update/:id', (req, res) => {
  const { name, price, description, image_url } = req.body;
  const { id } = req.params;
  db.query(
    'UPDATE menu_items SET name=?, price=?, description=?, image_url=? WHERE id=?',
    [name, price, description, image_url, id],
    (err, result) => {
      if (err) return res.json({ success: false });
      res.json({ success: true });
    }
  );
});
router.delete('/:id', (req, res) => {
  db.query('DELETE FROM menu_items WHERE id=?', [req.params.id], (err) => {
    res.json({ success: !err });
  });
});

module.exports = router;