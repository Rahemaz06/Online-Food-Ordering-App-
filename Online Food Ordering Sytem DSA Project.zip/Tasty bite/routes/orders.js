const express = require('express');
const router = express.Router();
const db = require('../db');

// POST place a new order
router.post('/place', (req, res) => {
  const { user_id, items, total_price, gst, payment_method, delivery_address } = req.body;

  // Validation
  if (!user_id || !items || items.length === 0)
    return res.json({ success: false, msg: 'user_id aur items zaroori hain' });

  db.query(
    'INSERT INTO orders (user_id, total_price, gst, payment_method, delivery_address, status) VALUES (?, ?, ?, ?, ?, ?)',
    [user_id, total_price, gst || 0, payment_method || 'cod', delivery_address, 'confirmed'],
    (err, result) => {
      if (err) return res.json({ success: false, msg: 'Order insert fail: ' + err.message });

      const orderId = result.insertId;

      // Map items — support both qty and quantity field names from frontend
      const vals = items.map(i => [
        orderId,
        i.id || i.item_id || null,
        i.name,
        i.price,
        i.qty || i.quantity || 1
      ]);

      db.query(
        'INSERT INTO order_items (order_id, menu_item_id, item_name, item_price, quantity) VALUES ?',
        [vals],
        (err2) => {
          if (err2) return res.json({ success: false, msg: 'Order items insert fail: ' + err2.message });

          // Clear cart after successful order
          db.query('DELETE FROM cart WHERE user_id=?', [user_id], () => {
            // Cart clear failure doesn't affect order success
          });

          res.json({ success: true, orderId });
        }
      );
    }
  );
});

// GET all orders for a specific user
router.get('/user/:userId', (req, res) => {
  db.query(
    `SELECT
       o.id,
       o.total_price,
       o.gst,
       o.delivery_charge,
       o.status,
       o.payment_method,
       o.delivery_address,
       o.created_at,
       GROUP_CONCAT(
         CONCAT(oi.item_name, ' x', oi.quantity)
         ORDER BY oi.id
         SEPARATOR ', '
       ) AS items_summary
     FROM orders o
     LEFT JOIN order_items oi ON o.id = oi.order_id
     WHERE o.user_id = ?
     GROUP BY o.id
     ORDER BY o.created_at DESC`,
    [req.params.userId],
    (err, rows) => {
      if (err) return res.json({ success: false, msg: err.message });
      res.json({ success: true, orders: rows });
    }
  );
});

// GET single order detail with all items
router.get('/detail/:orderId', (req, res) => {
  db.query(
    `SELECT o.id, o.total_price, o.gst, o.delivery_charge, o.status,
            o.payment_method, o.delivery_address, o.created_at,
            oi.item_name, oi.item_price, oi.quantity
     FROM orders o
     LEFT JOIN order_items oi ON o.id = oi.order_id
     WHERE o.id = ?`,
    [req.params.orderId],
    (err, rows) => {
      if (err) return res.json({ success: false, msg: err.message });
      res.json({ success: true, order: rows });
    }
  );
});

module.exports = router;